<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AudioController;

Route::resource('audio', AudioController::class);

Route::post('upload', [AudioController::class,'upload'])
    ->name('upload');
